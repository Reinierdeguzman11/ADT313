# Download the Project

# After downloading, extract the folder

# Using Command Prompt or VSCode Terminal, inside the project folder, run the `npm install`

# Run the project using `npm start`
