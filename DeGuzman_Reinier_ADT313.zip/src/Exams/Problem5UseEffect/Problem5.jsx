import { useEffect, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [inputValue, setInputValue] = useState('');
  const [isIdle, setIsIdle] = useState(true);

  useEffect(() => {
    
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer); 
  }, []);

  useEffect(() => {
    const idleTimer = setTimeout(() => {
      setIsIdle(true);
    }, 1000); 

    return () => clearTimeout(idleTimer); 
  }, [inputValue]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
    setIsIdle(false); 
  };

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' value={inputValue} onChange={handleInputChange} />
            <p>{isIdle ? 'User  is idle...' : 'User  is typing...'}</p>
          </div>
        </>
      )}
    </>
  );
}