import React, { useRef } from 'react';

function Problem3() {
  const inputRefs = useRef(Array.from({ length: 10 }, () => React.createRef())); 
  const handleButtonClick = () => {
    
    for (let i = 0; i < inputRefs.current.length; i++) {
      if (inputRefs.current[i].current && inputRefs.current[i].current.value === '') {
        inputRefs.current[i].current.focus(); 
        inputRefs.current[i].current.select(); 
        break; 
      }
    }
  };

  return (
    <>
      {Array.from({ length: 10 }, (_, index) => (
        <div key={index} style={{ display: 'block' }}>
          Input {index + 1}: <input type='text' ref={inputRefs.current[index]} />
        </div>
      ))}
      <button type='button' onClick={handleButtonClick}>
        I'm a button
      </button>
    </>
  );
}

export default Problem3;